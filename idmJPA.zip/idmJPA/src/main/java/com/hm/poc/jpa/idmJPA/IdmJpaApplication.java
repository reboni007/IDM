package com.hm.poc.jpa.idmJPA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IdmJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(IdmJpaApplication.class, args);
	}

}
