package com.hm.poc.jpa.idmJPA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IdmJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
