package com.hm.training.places;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlacesApplicationTests {

	@Test
	void contextLoads() {
	}

}
